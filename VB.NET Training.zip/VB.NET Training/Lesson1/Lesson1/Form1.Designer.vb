﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me._1Btn = New System.Windows.Forms.Button()
        Me._2Btn = New System.Windows.Forms.Button()
        Me._3Btn = New System.Windows.Forms.Button()
        Me._4Btn = New System.Windows.Forms.Button()
        Me._1Tlbl = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        '_1Btn
        '
        Me._1Btn.Location = New System.Drawing.Point(43, 61)
        Me._1Btn.Name = "_1Btn"
        Me._1Btn.Size = New System.Drawing.Size(94, 23)
        Me._1Btn.TabIndex = 0
        Me._1Btn.Text = "Click Me"
        Me._1Btn.UseVisualStyleBackColor = True
        '
        '_2Btn
        '
        Me._2Btn.Location = New System.Drawing.Point(43, 105)
        Me._2Btn.Name = "_2Btn"
        Me._2Btn.Size = New System.Drawing.Size(94, 23)
        Me._2Btn.TabIndex = 0
        Me._2Btn.Text = "Click Me Too"
        Me._2Btn.UseVisualStyleBackColor = True
        '
        '_3Btn
        '
        Me._3Btn.Location = New System.Drawing.Point(43, 151)
        Me._3Btn.Name = "_3Btn"
        Me._3Btn.Size = New System.Drawing.Size(94, 23)
        Me._3Btn.TabIndex = 0
        Me._3Btn.Text = "Click Me Three"
        Me._3Btn.UseVisualStyleBackColor = True
        '
        '_4Btn
        '
        Me._4Btn.Location = New System.Drawing.Point(153, 189)
        Me._4Btn.Name = "_4Btn"
        Me._4Btn.Size = New System.Drawing.Size(97, 23)
        Me._4Btn.TabIndex = 0
        Me._4Btn.Text = "Show Form 2"
        Me._4Btn.UseVisualStyleBackColor = True
        '
        '_1Tlbl
        '
        Me._1Tlbl.AutoSize = True
        Me._1Tlbl.Location = New System.Drawing.Point(67, 21)
        Me._1Tlbl.Name = "_1Tlbl"
        Me._1Tlbl.Size = New System.Drawing.Size(26, 13)
        Me._1Tlbl.TabIndex = 1
        Me._1Tlbl.Text = "GUI"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me._1Tlbl)
        Me.Controls.Add(Me._4Btn)
        Me.Controls.Add(Me._3Btn)
        Me.Controls.Add(Me._2Btn)
        Me.Controls.Add(Me._1Btn)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents _1Btn As System.Windows.Forms.Button
    Friend WithEvents _2Btn As System.Windows.Forms.Button
    Friend WithEvents _3Btn As System.Windows.Forms.Button
    Friend WithEvents _4Btn As System.Windows.Forms.Button
    Friend WithEvents _1Tlbl As System.Windows.Forms.Label

End Class
