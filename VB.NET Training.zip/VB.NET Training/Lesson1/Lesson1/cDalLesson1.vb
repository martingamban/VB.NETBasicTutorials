﻿Public Class cDalLesson1
    Public Shared ReadOnly Property Msg() As String
        Get
            Return MessageBox.Show("My First Data Access Layer", "From Dal")
        End Get
    End Property

    Shared Sub _pMyMsg()
        MessageBox.Show("My First Shared Property")
    End Sub
End Class

