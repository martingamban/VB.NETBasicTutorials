﻿Public Class BllButtons
    Public Shared Sub msg_box()
        MessageBox.Show("My First Business Logic Layer", "From Bll")
    End Sub
End Class
