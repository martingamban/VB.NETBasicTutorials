﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub _1Btn_Click(sender As Object, e As EventArgs) Handles _1Btn.Click


        Dim message As String = "Do you want to close this window?"

        Dim title As String = "From GUI"

        Dim buttons As MessageBoxButtons = MessageBoxButtons.YesNo

        Dim result As DialogResult = MessageBox.Show("My First VB.Net Form", "From GUI", buttons)

        If (result = DialogResult.Yes) Then

            Me.Close()

        Else

        End If

    End Sub

    Private Sub _2Btn_Click(sender As Object, e As EventArgs) Handles _2Btn.Click
        BllButtons.msg_box()
        
        Dim message As String = "Simple MessageBox"

        Dim title As String = "BllButtons"

    End Sub

    Private Sub _3Btn_Click(sender As Object, e As EventArgs) Handles _3Btn.Click

        cDalLesson1.Msg().ToString()

    End Sub

    Private Sub _4Btn_Click(sender As Object, e As EventArgs) Handles _4Btn.Click
        cDalLesson1._pMyMsg()
        Form2.Show()
    End Sub
End Class



