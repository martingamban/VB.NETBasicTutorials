﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me._1Tlbl = New System.Windows.Forms.Label()
        Me._1Btn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        '_1Tlbl
        '
        Me._1Tlbl.AutoSize = True
        Me._1Tlbl.Location = New System.Drawing.Point(55, 44)
        Me._1Tlbl.Name = "_1Tlbl"
        Me._1Tlbl.Size = New System.Drawing.Size(26, 13)
        Me._1Tlbl.TabIndex = 3
        Me._1Tlbl.Text = "GUI"
        '
        '_1Btn
        '
        Me._1Btn.Location = New System.Drawing.Point(31, 84)
        Me._1Btn.Name = "_1Btn"
        Me._1Btn.Size = New System.Drawing.Size(94, 23)
        Me._1Btn.TabIndex = 2
        Me._1Btn.Text = "Click Me"
        Me._1Btn.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me._1Tlbl)
        Me.Controls.Add(Me._1Btn)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents _1Tlbl As System.Windows.Forms.Label
    Friend WithEvents _1Btn As System.Windows.Forms.Button
End Class
