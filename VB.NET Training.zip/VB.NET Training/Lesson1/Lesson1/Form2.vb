﻿Public Class Form2

    Private Sub _1Btn_Click(sender As Object, e As EventArgs) Handles _1Btn.Click
        Dim message As String = "Simple MessageBox"

        Dim title As String = "From Dal"

        MessageBox.Show("My First Shared Property", "From Dal")
    End Sub
End Class