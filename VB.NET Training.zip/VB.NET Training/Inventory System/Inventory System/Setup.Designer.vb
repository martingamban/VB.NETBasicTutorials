﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Setup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt5 = New System.Windows.Forms.TextBox()
        Me.txt3 = New System.Windows.Forms.TextBox()
        Me.txt4 = New System.Windows.Forms.TextBox()
        Me.txt2 = New System.Windows.Forms.TextBox()
        Me.txt1 = New System.Windows.Forms.TextBox()
        Me.CloseBtn2 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.AddBtn2 = New System.Windows.Forms.Button()
        Me.DeleteBtn2 = New System.Windows.Forms.Button()
        Me.EditBtn2 = New System.Windows.Forms.Button()
        Me.PrintBtn2 = New System.Windows.Forms.Button()
        Me.CancelBtn2 = New System.Windows.Forms.Button()
        Me.SaveBtn2 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.RecordNumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateInputDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ItemCodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ItemDescriptionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalSupplyDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalSupplyLeftDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SimpleInventory2BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SimpleInventory1DataSet = New Inventory_System.SimpleInventory1DataSet()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.SimpleInventory2TableAdapter = New Inventory_System.SimpleInventory1DataSetTableAdapters.SimpleInventory2TableAdapter()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SimpleInventory2BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SimpleInventory1DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(96, 79)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(114, 20)
        Me.DateTimePicker1.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(451, 76)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(87, 13)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Total Supply Left"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(235, 76)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Item Description"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 79)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Date Input"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(459, 35)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Total Supply"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(235, 35)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Item Code"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(82, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Record Number"
        '
        'txt5
        '
        Me.txt5.Location = New System.Drawing.Point(544, 73)
        Me.txt5.Name = "txt5"
        Me.txt5.Size = New System.Drawing.Size(114, 20)
        Me.txt5.TabIndex = 3
        '
        'txt3
        '
        Me.txt3.Location = New System.Drawing.Point(320, 73)
        Me.txt3.Name = "txt3"
        Me.txt3.Size = New System.Drawing.Size(114, 20)
        Me.txt3.TabIndex = 3
        '
        'txt4
        '
        Me.txt4.Location = New System.Drawing.Point(544, 32)
        Me.txt4.Name = "txt4"
        Me.txt4.Size = New System.Drawing.Size(114, 20)
        Me.txt4.TabIndex = 3
        '
        'txt2
        '
        Me.txt2.Location = New System.Drawing.Point(320, 32)
        Me.txt2.Name = "txt2"
        Me.txt2.Size = New System.Drawing.Size(114, 20)
        Me.txt2.TabIndex = 3
        '
        'txt1
        '
        Me.txt1.Location = New System.Drawing.Point(96, 35)
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(114, 20)
        Me.txt1.TabIndex = 3
        '
        'CloseBtn2
        '
        Me.CloseBtn2.Location = New System.Drawing.Point(583, 37)
        Me.CloseBtn2.Name = "CloseBtn2"
        Me.CloseBtn2.Size = New System.Drawing.Size(75, 20)
        Me.CloseBtn2.TabIndex = 1
        Me.CloseBtn2.Text = "Close"
        Me.CloseBtn2.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txt5)
        Me.GroupBox1.Controls.Add(Me.txt3)
        Me.GroupBox1.Controls.Add(Me.txt4)
        Me.GroupBox1.Controls.Add(Me.txt2)
        Me.GroupBox1.Controls.Add(Me.txt1)
        Me.GroupBox1.Location = New System.Drawing.Point(53, 282)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(664, 108)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Data Input"
        '
        'AddBtn2
        '
        Me.AddBtn2.Location = New System.Drawing.Point(16, 37)
        Me.AddBtn2.Name = "AddBtn2"
        Me.AddBtn2.Size = New System.Drawing.Size(75, 20)
        Me.AddBtn2.TabIndex = 1
        Me.AddBtn2.Text = "Add"
        Me.AddBtn2.UseVisualStyleBackColor = True
        '
        'DeleteBtn2
        '
        Me.DeleteBtn2.Enabled = False
        Me.DeleteBtn2.Location = New System.Drawing.Point(178, 37)
        Me.DeleteBtn2.Name = "DeleteBtn2"
        Me.DeleteBtn2.Size = New System.Drawing.Size(75, 20)
        Me.DeleteBtn2.TabIndex = 1
        Me.DeleteBtn2.Text = "Delete"
        Me.DeleteBtn2.UseVisualStyleBackColor = True
        '
        'EditBtn2
        '
        Me.EditBtn2.Enabled = False
        Me.EditBtn2.Location = New System.Drawing.Point(97, 37)
        Me.EditBtn2.Name = "EditBtn2"
        Me.EditBtn2.Size = New System.Drawing.Size(75, 20)
        Me.EditBtn2.TabIndex = 1
        Me.EditBtn2.Text = "Edit"
        Me.EditBtn2.UseVisualStyleBackColor = True
        '
        'PrintBtn2
        '
        Me.PrintBtn2.Enabled = False
        Me.PrintBtn2.Location = New System.Drawing.Point(452, 37)
        Me.PrintBtn2.Name = "PrintBtn2"
        Me.PrintBtn2.Size = New System.Drawing.Size(75, 20)
        Me.PrintBtn2.TabIndex = 1
        Me.PrintBtn2.Text = "Print"
        Me.PrintBtn2.UseVisualStyleBackColor = True
        '
        'CancelBtn2
        '
        Me.CancelBtn2.Location = New System.Drawing.Point(268, 37)
        Me.CancelBtn2.Name = "CancelBtn2"
        Me.CancelBtn2.Size = New System.Drawing.Size(75, 20)
        Me.CancelBtn2.TabIndex = 1
        Me.CancelBtn2.Text = "Cancel"
        Me.CancelBtn2.UseVisualStyleBackColor = True
        '
        'SaveBtn2
        '
        Me.SaveBtn2.Enabled = False
        Me.SaveBtn2.Location = New System.Drawing.Point(360, 37)
        Me.SaveBtn2.Name = "SaveBtn2"
        Me.SaveBtn2.Size = New System.Drawing.Size(75, 20)
        Me.SaveBtn2.TabIndex = 1
        Me.SaveBtn2.Text = "Save"
        Me.SaveBtn2.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.RecordNumberDataGridViewTextBoxColumn, Me.DateInputDataGridViewTextBoxColumn, Me.ItemCodeDataGridViewTextBoxColumn, Me.ItemDescriptionDataGridViewTextBoxColumn, Me.TotalSupplyDataGridViewTextBoxColumn, Me.TotalSupplyLeftDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.SimpleInventory2BindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(53, 26)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(664, 250)
        Me.DataGridView1.TabIndex = 3
        '
        'RecordNumberDataGridViewTextBoxColumn
        '
        Me.RecordNumberDataGridViewTextBoxColumn.DataPropertyName = "RecordNumber"
        Me.RecordNumberDataGridViewTextBoxColumn.HeaderText = "RecordNumber"
        Me.RecordNumberDataGridViewTextBoxColumn.Name = "RecordNumberDataGridViewTextBoxColumn"
        Me.RecordNumberDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DateInputDataGridViewTextBoxColumn
        '
        Me.DateInputDataGridViewTextBoxColumn.DataPropertyName = "DateInput"
        Me.DateInputDataGridViewTextBoxColumn.HeaderText = "DateInput"
        Me.DateInputDataGridViewTextBoxColumn.Name = "DateInputDataGridViewTextBoxColumn"
        Me.DateInputDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ItemCodeDataGridViewTextBoxColumn
        '
        Me.ItemCodeDataGridViewTextBoxColumn.DataPropertyName = "ItemCode"
        Me.ItemCodeDataGridViewTextBoxColumn.HeaderText = "ItemCode"
        Me.ItemCodeDataGridViewTextBoxColumn.Name = "ItemCodeDataGridViewTextBoxColumn"
        Me.ItemCodeDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ItemDescriptionDataGridViewTextBoxColumn
        '
        Me.ItemDescriptionDataGridViewTextBoxColumn.DataPropertyName = "ItemDescription"
        Me.ItemDescriptionDataGridViewTextBoxColumn.HeaderText = "ItemDescription"
        Me.ItemDescriptionDataGridViewTextBoxColumn.Name = "ItemDescriptionDataGridViewTextBoxColumn"
        Me.ItemDescriptionDataGridViewTextBoxColumn.ReadOnly = True
        '
        'TotalSupplyDataGridViewTextBoxColumn
        '
        Me.TotalSupplyDataGridViewTextBoxColumn.DataPropertyName = "TotalSupply"
        Me.TotalSupplyDataGridViewTextBoxColumn.HeaderText = "TotalSupply"
        Me.TotalSupplyDataGridViewTextBoxColumn.Name = "TotalSupplyDataGridViewTextBoxColumn"
        Me.TotalSupplyDataGridViewTextBoxColumn.ReadOnly = True
        '
        'TotalSupplyLeftDataGridViewTextBoxColumn
        '
        Me.TotalSupplyLeftDataGridViewTextBoxColumn.DataPropertyName = "TotalSupplyLeft"
        Me.TotalSupplyLeftDataGridViewTextBoxColumn.HeaderText = "TotalSupplyLeft"
        Me.TotalSupplyLeftDataGridViewTextBoxColumn.Name = "TotalSupplyLeftDataGridViewTextBoxColumn"
        Me.TotalSupplyLeftDataGridViewTextBoxColumn.ReadOnly = True
        '
        'SimpleInventory2BindingSource
        '
        Me.SimpleInventory2BindingSource.DataMember = "SimpleInventory2"
        Me.SimpleInventory2BindingSource.DataSource = Me.SimpleInventory1DataSet
        '
        'SimpleInventory1DataSet
        '
        Me.SimpleInventory1DataSet.DataSetName = "SimpleInventory1DataSet"
        Me.SimpleInventory1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.TextBox1)
        Me.GroupBox2.Controls.Add(Me.AddBtn2)
        Me.GroupBox2.Controls.Add(Me.CloseBtn2)
        Me.GroupBox2.Controls.Add(Me.DeleteBtn2)
        Me.GroupBox2.Controls.Add(Me.EditBtn2)
        Me.GroupBox2.Controls.Add(Me.PrintBtn2)
        Me.GroupBox2.Controls.Add(Me.CancelBtn2)
        Me.GroupBox2.Controls.Add(Me.SaveBtn2)
        Me.GroupBox2.Location = New System.Drawing.Point(52, 396)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(664, 108)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Data Manipulation"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(16, 72)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(41, 13)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "Search"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(63, 69)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(114, 20)
        Me.TextBox1.TabIndex = 2
        '
        'SimpleInventory2TableAdapter
        '
        Me.SimpleInventory2TableAdapter.ClearBeforeFill = True
        '
        'Setup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(768, 515)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Name = "Setup"
        Me.Text = "Setup"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SimpleInventory2BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SimpleInventory1DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt5 As System.Windows.Forms.TextBox
    Friend WithEvents txt3 As System.Windows.Forms.TextBox
    Friend WithEvents txt4 As System.Windows.Forms.TextBox
    Friend WithEvents txt2 As System.Windows.Forms.TextBox
    Friend WithEvents txt1 As System.Windows.Forms.TextBox
    Friend WithEvents CloseBtn2 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents AddBtn2 As System.Windows.Forms.Button
    Friend WithEvents DeleteBtn2 As System.Windows.Forms.Button
    Friend WithEvents EditBtn2 As System.Windows.Forms.Button
    Friend WithEvents PrintBtn2 As System.Windows.Forms.Button
    Friend WithEvents CancelBtn2 As System.Windows.Forms.Button
    Friend WithEvents SaveBtn2 As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents SimpleInventory1DataSet As SimpleInventory1DataSet
    Friend WithEvents SimpleInventory2BindingSource As BindingSource
    Friend WithEvents SimpleInventory2TableAdapter As SimpleInventory1DataSetTableAdapters.SimpleInventory2TableAdapter
    Friend WithEvents RecordNumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DateInputDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ItemCodeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ItemDescriptionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TotalSupplyDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TotalSupplyLeftDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
