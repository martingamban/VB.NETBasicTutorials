﻿Imports System.Data.SqlClient

Public Class Transaction



    Private Sub AddBtn1_Click(sender As Object, e As EventArgs) Handles AddBtn1.Click
        OpenDB()


        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Then

            MsgBox("fill the Info", vbCritical)

        Else

            cmd = con.CreateCommand
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "INSERT INTO TransEntry values('" + TextBox1.Text + "', '" + DateTimePicker2.Value.Date + "', '" + TextBox2.Text + "', '" + ComboBox1.Text + "', '" + TextBox3.Text + "', '" + TextBox4.Text + "')"

            cmd.ExecuteNonQuery()
            Display_Data()
        End If
    End Sub

    Private Sub EditBtn1_Click(sender As Object, e As EventArgs) Handles EditBtn1.Click
        OpenDB()


        cmd = con.CreateCommand
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "Update TransEntry set TransactionDate = '" + DateTimePicker2.Value.Date + "', AccountName = '" + TextBox2.Text + "', ItemCode =  '" + ComboBox1.Text + "', ItemDescription = '" + TextBox3.Text + "', NumberOfItem =  '" + TextBox4.Text + "' where RecordNumber = '" & TextBox1.Text & "'"

        cmd.ExecuteNonQuery()

        Display_Data()
    End Sub

    Private Sub DeleteBtn1_Click(sender As Object, e As EventArgs) Handles DeleteBtn1.Click

        OpenDB()

        cmd = con.CreateCommand
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "DELETE FROM TransEntry WHERE RecordNumber = '" + TextBox1.Text + "' "

        cmd.ExecuteNonQuery()
        Display_Data()

    End Sub

    Private Sub CancelBtn1_Click(sender As Object, e As EventArgs) Handles CancelBtn1.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        ComboBox1.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
    End Sub

    Private Sub SaveBtn1_Click(sender As Object, e As EventArgs) Handles SaveBtn1.Click

    End Sub

    Private Sub PrintBtn1_Click(sender As Object, e As EventArgs) Handles PrintBtn1.Click

    End Sub





    Private Sub Transaction_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        OpenDB()

        Display_Data()
    End Sub

    Public Sub Display_Data()
        cmd = con.CreateCommand()

        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT * FROM TransEntry"
        cmd.ExecuteNonQuery()

        Dim Dt As New DataTable
        Dim DA As New SqlDataAdapter(cmd)
        DA.Fill(Dt)

        DataGridView2.DataSource = Dt




    End Sub

    Private Sub CloseBtn1_Click(sender As Object, e As EventArgs) Handles CloseBtn1.Click
        Me.Hide()
        Simple_Inventory.Show()
    End Sub

    Private Sub DataGridView2_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView2.CellClick
        Try
            OpenDB()


            i = Convert.ToInt32(DataGridView2.SelectedCells.Item(0).Value.ToString())

            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select * From TransEntry where RecordNumber  = " & i & ""
            cmd.ExecuteNonQuery()

            Dim dt As New DataTable()
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)

            Dim dr As SqlClient.SqlDataReader
            dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            While dr.Read

                TextBox1.Text = dr.GetString(0).ToString()
                DateTimePicker2.Value = dr.GetDateTime(1).ToString()
                TextBox2.Text = dr.GetString(2).ToString()
                ComboBox1.Text = dr.GetString(3).ToString()
                TextBox3.Text = dr.GetString(4).ToString()
                TextBox4.Text = dr.GetString(5).ToString()



            End While

            dr.Close()



        Catch ex As Exception

        End Try



    End Sub
End Class
