﻿Imports System.Data.SqlClient

Public Class Setup
    Private Sub Setup_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SimpleInventory1DataSet.SimpleInventory2' table. You can move, or remove it, as needed.
        Me.SimpleInventory2TableAdapter.Fill(Me.SimpleInventory1DataSet.SimpleInventory2)

        OpenDB()

        Display_Data()
    End Sub

    Public Sub Display_Data()
        cmd = con.CreateCommand()

        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT * FROM SimpleInventory2"
        cmd.ExecuteNonQuery()

        Dim Dt As New DataTable
        Dim DA As New SqlDataAdapter(cmd)
        DA.Fill(Dt)

        DataGridView1.DataSource = Dt



    End Sub

    Private Sub AddBtn2_Click(sender As Object, e As EventArgs) Handles AddBtn2.Click
        OpenDB()

        txt4.Text = txt5.Text
        DeleteBtn2.Enabled = True
        EditBtn2.Enabled = True
        SaveBtn2.Enabled = True
        PrintBtn2.Enabled = True



        If txt1.Text = "" Or txt2.Text = "" Or txt3.Text = "" Or txt4.Text = "" Or txt5.Text = "" Then

            MsgBox("fill the Info", vbCritical)

        Else

            cmd = con.CreateCommand
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "INSERT INTO SimpleInventory2 values('" + txt1.Text + "', '" + DateTimePicker1.Value.Date + "', '" + txt2.Text + "',  '" + txt3.Text + "', '" + txt4.Text + "', '" + txt5.Text + "')"

            cmd.ExecuteNonQuery()
            Display_Data()
        End If
    End Sub

    Private Sub EditBtn2_Click(sender As Object, e As EventArgs) Handles EditBtn2.Click
        OpenDB()
        txt4.Text = txt5.Text

        cmd = con.CreateCommand
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "Update SimpleInventory2 set DateInput = '" + DateTimePicker1.Value.Date + "', ItemCode = '" + txt2.Text + "', ItemDescription = '" + txt3.Text + "', TotalSupply = '" + txt4.Text + "', TotalSupplyLeft = '" + txt5.Text + "' where RecordNumber = '" + txt1.Text + "'"

        cmd.ExecuteNonQuery()

        Display_Data()
    End Sub

    Private Sub DeleteBtn2_Click(sender As Object, e As EventArgs) Handles DeleteBtn2.Click
        OpenDB()

        cmd = con.CreateCommand
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "DELETE FROM SimpleInventory2 WHERE RecordNumber = '" + txt1.Text + "' "

        cmd.ExecuteNonQuery()
        Display_Data()
    End Sub

    Private Sub CancelBtn2_Click(sender As Object, e As EventArgs) Handles CancelBtn2.Click
        'txt1.Text = ""
        'txt2.Text = ""
        'txt3.Text = ""
        'txt4.Text = ""
        'txt5.Text = ""

        EditBtn2.Enabled = False
        DeleteBtn2.Enabled = False
        SaveBtn2.Enabled = False
        PrintBtn2.Enabled = False
    End Sub

    Private Sub SaveBtn2_Click(sender As Object, e As EventArgs) Handles SaveBtn2.Click

    End Sub

    Private Sub PrintBtn2_Click(sender As Object, e As EventArgs) Handles PrintBtn2.Click

    End Sub

    Private Sub CloseBtn2_Click(sender As Object, e As EventArgs) Handles CloseBtn2.Click
        Me.Hide()

        Simple_Inventory.Show()
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick

        Try
            OpenDB()
            i = Convert.ToInt32(DataGridView1.SelectedCells.Item(0).Value.ToString())

            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select * From SimpleInventory2 where RecordNumber  = " & i & ""
            cmd.ExecuteNonQuery()

            Dim dt As New DataTable()
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)

            Dim dr As SqlClient.SqlDataReader
            dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            While dr.Read

                txt1.Text = dr.GetString(0).ToString()
                DateTimePicker1.Value = dr.GetDateTime(1).ToString()
                txt2.Text = dr.GetString(2).ToString()
                txt3.Text = dr.GetString(3).ToString()
                txt4.Text = dr.GetString(4).ToString()
                txt5.Text = dr.GetString(5).ToString()


            End While

            dr.Close()


        Catch ex As Exception

            'MessageBox.Show("No item found")
        End Try
    End Sub

    Private Sub txt4_TextChanged(sender As Object, e As EventArgs) Handles txt4.TextChanged

    End Sub

    Private Sub txt4_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt4.KeyPress

        If Asc(e.KeyChar) <> 8 Then
            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        FilterData(TextBox1.Text)
    End Sub
    Public Sub DataGrid()

        Dim Dt As New DataTable
        Dim DA As New SqlDataAdapter(cmd)
        DA.Fill(Dt)

        DataGridView1.DataSource = Dt
    End Sub
End Class