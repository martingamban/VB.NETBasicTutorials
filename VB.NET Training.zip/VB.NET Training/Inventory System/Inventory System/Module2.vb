﻿Imports System.Data.SqlClient

Module Module2

    Public con As New SqlConnection
    Public cmd As New SqlCommand
    Public i As String
    Public Sub OpenDB()
        If con.State = ConnectionState.Open Then
            con.Close()

        End If

        con.Open()
    End Sub

    Public Sub FilterData(Value)
        OpenDB()

        cmd = con.CreateCommand
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "Select  * From SimpleInventory2 Where ItemDescription Like '%" & Value & "%'"

        cmd.ExecuteNonQuery()

        Setup.DataGrid()
    End Sub
End Module
