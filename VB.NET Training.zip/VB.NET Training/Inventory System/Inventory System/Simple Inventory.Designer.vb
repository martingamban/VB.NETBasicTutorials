﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Simple_Inventory
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ItemSetupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransactionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransactionModuleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InquiryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetupReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransactionReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.TransactionToolStripMenuItem, Me.InquiryToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ItemSetupToolStripMenuItem, Me.LogOutToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ItemSetupToolStripMenuItem
        '
        Me.ItemSetupToolStripMenuItem.Name = "ItemSetupToolStripMenuItem"
        Me.ItemSetupToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ItemSetupToolStripMenuItem.Text = "Item Setup"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'TransactionToolStripMenuItem
        '
        Me.TransactionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TransactionModuleToolStripMenuItem})
        Me.TransactionToolStripMenuItem.Name = "TransactionToolStripMenuItem"
        Me.TransactionToolStripMenuItem.Size = New System.Drawing.Size(79, 20)
        Me.TransactionToolStripMenuItem.Text = "Transaction"
        '
        'TransactionModuleToolStripMenuItem
        '
        Me.TransactionModuleToolStripMenuItem.Name = "TransactionModuleToolStripMenuItem"
        Me.TransactionModuleToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.TransactionModuleToolStripMenuItem.Text = "Transaction Module"
        '
        'InquiryToolStripMenuItem
        '
        Me.InquiryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SetupReportToolStripMenuItem, Me.TransactionReportToolStripMenuItem})
        Me.InquiryToolStripMenuItem.Name = "InquiryToolStripMenuItem"
        Me.InquiryToolStripMenuItem.Size = New System.Drawing.Size(56, 20)
        Me.InquiryToolStripMenuItem.Text = "Inquiry"
        '
        'SetupReportToolStripMenuItem
        '
        Me.SetupReportToolStripMenuItem.Name = "SetupReportToolStripMenuItem"
        Me.SetupReportToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.SetupReportToolStripMenuItem.Text = "Setup Report"
        '
        'TransactionReportToolStripMenuItem
        '
        Me.TransactionReportToolStripMenuItem.Name = "TransactionReportToolStripMenuItem"
        Me.TransactionReportToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.TransactionReportToolStripMenuItem.Text = "Transaction Report"
        '
        'Simple_Inventory
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Simple_Inventory"
        Me.Text = "Simple_Inventory"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ItemSetupToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogOutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TransactionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TransactionModuleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents InquiryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SetupReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TransactionReportToolStripMenuItem As ToolStripMenuItem
End Class
