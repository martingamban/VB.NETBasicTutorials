﻿Public Class Simple_Inventory
    Private Sub Simple_Inventory_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        con.ConnectionString = "Data Source=DOHA\MSSQL2008R2;Initial Catalog=SimpleInventory1;User ID=sa;Password=P@ssw0rd"
        OpenDB()

    End Sub

    Private Sub TransactionModuleToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TransactionModuleToolStripMenuItem.Click
        Transaction.Show()
    End Sub

    Private Sub SetupReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SetupReportToolStripMenuItem.Click

    End Sub

    Private Sub ItemSetupToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ItemSetupToolStripMenuItem.Click
        Setup.Show()
    End Sub
End Class