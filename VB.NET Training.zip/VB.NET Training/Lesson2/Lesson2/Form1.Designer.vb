﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me._oNumDigit = New System.Windows.Forms.NumericUpDown()
        Me._oNumValue = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me._1Btn = New System.Windows.Forms.Button()
        Me._2Btn = New System.Windows.Forms.Button()
        CType(Me._oNumDigit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._oNumValue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        '_oNumDigit
        '
        Me._oNumDigit.Location = New System.Drawing.Point(68, 62)
        Me._oNumDigit.Name = "_oNumDigit"
        Me._oNumDigit.Size = New System.Drawing.Size(120, 20)
        Me._oNumDigit.TabIndex = 0
        '
        '_oNumValue
        '
        Me._oNumValue.Location = New System.Drawing.Point(68, 99)
        Me._oNumValue.Name = "_oNumValue"
        Me._oNumValue.Size = New System.Drawing.Size(120, 20)
        Me._oNumValue.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Digit"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 101)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(34, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Value"
        '
        '_1Btn
        '
        Me._1Btn.Location = New System.Drawing.Point(12, 167)
        Me._1Btn.Name = "_1Btn"
        Me._1Btn.Size = New System.Drawing.Size(123, 23)
        Me._1Btn.TabIndex = 2
        Me._1Btn.Text = "Get Format Bll"
        Me._1Btn.UseVisualStyleBackColor = True
        '
        '_2Btn
        '
        Me._2Btn.Location = New System.Drawing.Point(149, 167)
        Me._2Btn.Name = "_2Btn"
        Me._2Btn.Size = New System.Drawing.Size(123, 23)
        Me._2Btn.TabIndex = 2
        Me._2Btn.Text = "Get Format Dal"
        Me._2Btn.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me._2Btn)
        Me.Controls.Add(Me._1Btn)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me._oNumValue)
        Me.Controls.Add(Me._oNumDigit)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me._oNumDigit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._oNumValue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents _oNumDigit As System.Windows.Forms.NumericUpDown
    Friend WithEvents _oNumValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents _1Btn As System.Windows.Forms.Button
    Friend WithEvents _2Btn As System.Windows.Forms.Button

End Class
