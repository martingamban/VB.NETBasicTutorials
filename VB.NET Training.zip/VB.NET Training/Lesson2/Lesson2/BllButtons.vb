﻿Public Class BllButtons
    Public Shared ReadOnly Property Msg() As String
        Get
            Return MessageBox.Show("My First Function : <Display Output Here>", "From Bll")
        End Get
    End Property
End Class
