﻿Public Class Form1

    Private Sub _1Btn_Click(sender As Object, e As EventArgs) Handles _1Btn.Click
        BllButtons.Msg().ToString()

        Dim message As String = "Simple MessageBox"

        Dim title As String = "From Bll"

    End Sub

    Private Sub _2Btn_Click(sender As Object, e As EventArgs) Handles _2Btn.Click

        Lesson2.ClassResult.cDalFormatNumber()


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub _1Num_ValueChanged(sender As Object, e As EventArgs) Handles _oNumDigit.ValueChanged

    End Sub
End Class
