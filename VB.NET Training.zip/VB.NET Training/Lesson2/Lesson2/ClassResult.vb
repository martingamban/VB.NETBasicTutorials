﻿Public Class ClassResult
    Shared Sub cDalFormatNumber()

        Dim _pDigit As Integer = Lesson2.Form1._oNumDigit.Value
        Dim _pValue As Integer = Lesson2.Form1._oNumValue.Value
        Dim _pResult As Integer = _pDigit + _pValue

        MessageBox.Show("My First Function : " & _pResult)

    End Sub
End Class
