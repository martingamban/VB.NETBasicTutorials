﻿Imports System.Data.SqlClient

Module Module1
    Public con As New SqlConnection
    Public cmd As New SqlCommand

    Public Sub OpenDB()
        If con.State = ConnectionState.Open Then
            con.Close()

        End If

        con.Open()

    End Sub
End Module
