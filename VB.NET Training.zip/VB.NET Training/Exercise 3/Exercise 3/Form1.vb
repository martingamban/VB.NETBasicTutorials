﻿Imports System.Data.SqlClient


Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        con.ConnectionString = "Data Source=doha\mssql2008r2;Initial Catalog=SQLTraining;User ID=sa;Password=P@ssw0rd"

        OpenDB()
        Display_Data()
    End Sub


    Public Sub Display_Data()
        cmd = con.CreateCommand()

        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT * FROM teacher"
        cmd.ExecuteNonQuery()

        Dim Dt As New DataTable
        Dim DA As New SqlDataAdapter(cmd)
        DA.Fill(Dt)

        DataGridView1.DataSource = Dt
    End Sub
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class
