﻿Imports System.Data.SqlClient

Module Module1
    Public con As New SqlConnection
    Public cmd As New SqlCommand
    Public i As String
    Public Sub OpenDB()
        If con.State = ConnectionState.Open Then
            con.Close()

        End If

        con.Open()

    End Sub

    Public Sub FilterData(Value As String)

        OpenDB()
        cmd = con.CreateCommand
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "Select * From student where concat(firstname, lastname, middlename) Like '%" & Value & "%'"
        cmd.ExecuteNonQuery()

        Form1.DataGrid()


    End Sub
End Module
