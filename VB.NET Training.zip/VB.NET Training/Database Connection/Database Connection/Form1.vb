﻿Imports System.Data.SqlClient

Public Class Form1

     Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'con.ConnectionString = "Data Source=doha\mssql2008r2;Initial Catalog=SQLTraining;User ID=sa;Password=P@ssw0rd"
        con.ConnectionString = "Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\asmara\Desktop\Martin\VB.NET Training\Database Connection\Database Connection\Database1.mdf;Integrated Security=True"
        OpenDB()
        Display_Data()
    End Sub


    Public Sub Display_Data()
        cmd = con.CreateCommand()

        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT * FROM student"
        cmd.ExecuteNonQuery()

        Dim Dt As New DataTable
        Dim DA As New SqlDataAdapter(cmd)
        DA.Fill(Dt)

        DataGridView1.DataSource = Dt



    End Sub

    Private Sub _1Btn_Click(sender As Object, e As EventArgs) Handles _1Btn.Click
        OpenDB()

        cmd = con.CreateCommand
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "INSERT INTO student values('" + txt1.Text + "',  '" + txt2.Text + "', '" + txt3.Text + "', '" + txt4.Text + "' , '" + DateTimePicker1.Value.Date + "' , '" + txt6.Text + "' , '" + txt7.Text + "', '" + txt8.Text + "', '" + txt9.Text + "')"

        cmd.ExecuteNonQuery()
        Display_Data()


    End Sub

    Private Sub _4Btn_Click(sender As Object, e As EventArgs) Handles _4Btn.Click

        OpenDB()

        cmd = con.CreateCommand
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "DELETE FROM student WHERE student_id = '" + txt1.Text + "' "

        cmd.ExecuteNonQuery()
        Display_Data()


    End Sub

    Private Sub _3Btn_Click(sender As Object, e As EventArgs) Handles _3Btn.Click
        OpenDB()

        cmd = con.CreateCommand
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "Update student set lastname = '" + txt2.Text + "', firstname = '" + txt3.Text + "', middlename = '" + txt4.Text + "', birthdate = '" + DateTimePicker1.Value.Date + "', sex = '" + txt6.Text + "', Religion = '" + txt7.Text + "', Height = '" + txt8.Text + "', Weight = '" + txt9.Text + "'where student_id = '" + txt1.Text + "'"

        cmd.ExecuteNonQuery()

        Display_Data()
    End Sub



    Public Sub DataGrid()

        Dim Dt As New DataTable
        Dim DA As New SqlDataAdapter(cmd)
        DA.Fill(Dt)

        DataGridView1.DataSource = Dt
    End Sub



    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            OpenDB()


            i = Convert.ToInt32(DataGridView1.SelectedCells.Item(0).Value.ToString())

            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select * From student where student_id = " & i & ""
            cmd.ExecuteNonQuery()

            Dim dt As New DataTable()
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)

            Dim dr As SqlClient.SqlDataReader
            dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            While dr.Read

                txt1.Text = dr.GetString(0).ToString()
                txt2.Text = dr.GetString(1).ToString()
                txt3.Text = dr.GetString(2).ToString()
                txt4.Text = dr.GetString(3).ToString()
                txt6.Text = dr.GetString(5).ToString()
                txt7.Text = dr.GetString(6).ToString()
                txt8.Text = dr.GetString(7).ToString()
                txt9.Text = dr.GetString(8).ToString()

            End While

            dr.Close()
        Catch ex As Exception
            MessageBox.Show("No item found")
        End Try
    End Sub

    
    Private Sub txt10_TextChanged(sender As Object, e As EventArgs) Handles txt10.TextChanged
        FilterData(txt10.Text)

    End Sub
End Class


